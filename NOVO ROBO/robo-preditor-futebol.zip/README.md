# Robô Preditor de Futebol
Este projeto usa um modelo de aprendizado de máquina simples para prever o resultado de partidas de futebol com base em nomes dos times.